package com.example.callingapp

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import java.net.URLEncoder
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

@Composable
fun DialPadApp() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "dial") {
        composable("dial") {
            DialPadScreen(navController)
        }

        composable(
            "outgoing/{number}",
            arguments = listOf(navArgument("number") { type = NavType.StringType })
        ) { backStackEntry ->
            val encodedNumber = backStackEntry.arguments?.getString("number") ?: ""
            val number = URLDecoder.decode(encodedNumber, StandardCharsets.UTF_8.toString())
            OutgoingScreen(number)
        }
    }
}

@Composable
fun DialPadScreen(navController: NavController) {

    var number by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp)
    ) {

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            //User will enter the number
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 120.dp, bottom = 8.dp)
            ) {

                TextField(
                    value = number,
                    onValueChange = {
                        if (it.length <= 10 && it.all { ch ->
                                ch.isDigit() || ch == '*' || ch == '#'
                            }) {
                            number = it
                        }
                    },
                    placeholder = { Text("Enter number", color = Color.Gray) },
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 28.sp),
                    modifier = Modifier.weight(1f)
                )

                // cross button to cut the number from last -> one by one number will remove
                IconButton(
                    onClick = {
                        if (number.isNotEmpty()) {
                            number = number.dropLast(1)
                        }
                    },
                    modifier = Modifier.padding(start = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Delete",
                        tint = Color.White
                    )
                }
            }

            // Numbers Button
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                DialRow(listOf("1", "2", "3")) { if (number.length < 10) number += it }
                DialRow(listOf("4", "5", "6")) { if (number.length < 10) number += it }
                DialRow(listOf("7", "8", "9")) { if (number.length < 10) number += it }

                Row(
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    DialButton("*") { if (number.length < 10) number += '*' }
                    DialButton("0") { if (number.length < 10) number += '0' }
                    DialButton("#") { if (number.length < 10) number += '#' }
                }
            }
        }

        //  Call button
        Button(
            onClick = {
                if (number.isNotEmpty()) {
                    // Encode special characters (*, #)
                    val encodedNumber = URLEncoder.encode(number, StandardCharsets.UTF_8.toString())
                    navController.navigate("outgoing/$encodedNumber")
                }
            },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 20.dp)
                .size(80.dp),
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF53B84C)
            )
        ) {
            Image(
                painter = painterResource(id = R.drawable.call_image),
                contentDescription = "Call",
                colorFilter = ColorFilter.tint(Color.White),
                modifier = Modifier.size(30.dp)
            )
        }
    }
}

@Composable
fun DialRow(numbers: List<String>, onClick: (Char) -> Unit) {
    Row(
        horizontalArrangement = Arrangement.Center,
        modifier = Modifier.fillMaxWidth()
    ) {
        numbers.forEach { num ->
            DialButton(num) {
                if (num.length == 1) onClick(num[0])
            }
        }
    }
}

@Composable
fun DialButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .padding(8.dp)
            .size(80.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Gray,
            contentColor = Color.White
        )
    ) {
        Text(text = text, fontSize = 27.sp)
    }
}

@Composable
fun OutgoingScreen(number: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.DarkGray),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "Calling...",
                fontSize = 32.sp,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = number,
                fontSize = 28.sp,
                color = Color.White
            )
        }
    }
}