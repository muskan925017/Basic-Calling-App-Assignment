package com.example.callingapp

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "dial") {

        // Dial Screen
        composable("dial") {
            DialScreen(navController)
        }

        // Dial Pad Screen
        composable("dialpad") {
            DialPadScreen(navController)
        }

        // Outgoing Screen
        composable(
            "outgoing/{number}",
            arguments = listOf(navArgument("number") { type = NavType.StringType })
        ) { backStackEntry ->
            val encodedNumber = backStackEntry.arguments?.getString("number") ?: ""
            val number = URLDecoder.decode(encodedNumber, StandardCharsets.UTF_8.toString())
            OutgoingScreen(number, navController)
        }
        composable(
            "incoming/{number}",
            arguments = listOf(navArgument("number") { type = NavType.StringType })
        ) { backStackEntry ->
            // Decode number to handle *, # symbols
            val encodedNumber = backStackEntry.arguments?.getString("number") ?: ""
            val number = java.net.URLDecoder.decode(
                encodedNumber,
                java.nio.charset.StandardCharsets.UTF_8.toString()
            )
            IncomingScreen(number = number, navController = navController)
        }

        composable(
            route = "activecall/{number}",
            arguments = listOf(navArgument("number") { type = NavType.StringType })
        ) { backStackEntry ->
            val number = backStackEntry.arguments?.getString("number") ?: ""
            ActiveCallScreen(number = number, navController = navController)
        }
    }
}