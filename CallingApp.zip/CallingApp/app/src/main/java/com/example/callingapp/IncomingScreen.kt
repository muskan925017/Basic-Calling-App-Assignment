package com.example.callingapp

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

@Composable
fun IncomingScreen(number: String, navController: NavController) {
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(vertical = 80.dp),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        //User number
        Text(
            text = number,
            fontSize = 35.sp,
            color = Color.White
        )

        // Accept & Reject buttons
        Row(
            horizontalArrangement = Arrangement.spacedBy(60.dp),
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 50.dp)
        ) {
            // Red button to reject call
            Button(
                onClick = {
                    scope.launch {
                        delay(300) // optional animation delay
                        navController.navigate("dialpad") {
                            popUpTo("dial") { inclusive = false }
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Black)
            ) {
                Image(
                    painter = painterResource(R.drawable.reject_btn),
                    contentDescription = "Reject Call"
                )
            }

            // Green button to accept call
            Button(
                onClick = {
                    scope.launch {
                        delay(300)
                        // Encode number to special characters
                        val encodedNumber = URLEncoder.encode(
                            number,
                            StandardCharsets.UTF_8.toString()
                        )
                        navController.navigate("activecall/$encodedNumber")
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Black)
            ) {
                Image(
                    painter = painterResource(R.drawable.accept_btn),
                    contentDescription = "Accept Call"
                )
            }
        }
    }
}