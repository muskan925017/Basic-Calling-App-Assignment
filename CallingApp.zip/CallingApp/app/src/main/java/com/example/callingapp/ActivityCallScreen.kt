package com.example.callingapp

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ActiveCallScreen(number: String, navController: NavController) {
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 40.dp)
        ) {
            Text(
                text = number,
                fontSize = 30.sp,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(16.dp))

            CallTimer()
        }
        //Mute and Speaker Button
        Row(
            horizontalArrangement = Arrangement.spacedBy(40.dp),
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 20.dp)
        ) {
            var isMuted by remember { mutableStateOf(false) }
            var isSpeakerOn by remember { mutableStateOf(false) }

            // Mute Button
            Button(
                onClick = { isMuted = !isMuted },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isMuted) Color.Red else Color.Gray
                ),
                shape = CircleShape,
                modifier = Modifier.size(70.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text(if (isMuted) "Unmute" else "Mute", color = Color.White, fontSize = 12.sp)
            }

            // Speaker Button
            Button(
                onClick = { isSpeakerOn = !isSpeakerOn },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isSpeakerOn) Color.Green else Color.Gray
                ),
                shape = CircleShape,
                modifier = Modifier.size(70.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text(if (isSpeakerOn) "Speaker On" else "Speaker Off", color = Color.White, fontSize = 12.sp)
            }
        }

        //End Call Button to cut the call
        Button(
            onClick = {
                scope.launch {
                    delay(100)
                    navController.navigate("dialpad") {
                        popUpTo("dial") { inclusive = false }
                    }
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = PaddingValues(0.dp),
            modifier = Modifier
                .size(100.dp)
                .padding(bottom = 40.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(Color.Red),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "End Call",
                    color = Color.White,
                    fontSize = 20.sp
                )
            }
        }
    }
}

@Composable
fun CallTimer() {
    var seconds by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            seconds++
        }
    }

    val minutesDisplay = (seconds / 60).toString().padStart(2, '0')
    val secondsDisplay = (seconds % 60).toString().padStart(2, '0')

    Text(
        text = "$minutesDisplay:$secondsDisplay",
        fontSize = 24.sp,
        color = Color.White
    )
}

