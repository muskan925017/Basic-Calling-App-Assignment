package com.example.callingapp

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun OutgoingScreen(number: String, navController: NavController) {
    val scope = rememberCoroutineScope()
    var callEnded by remember { mutableStateOf(false) } //track the user that user cuts the call or not

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(vertical = 80.dp),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = number, fontSize = 35.sp, color = Color.White)
            Spacer(modifier = Modifier.height(12.dp))
            Text(text = "Calling...", fontSize = 23.sp, color = Color.Gray)
            Spacer(modifier = Modifier.height(40.dp))
        }

        // End Call Button
        Button(
            onClick = {
                scope.launch {
                    callEnded = true
                    navController.navigate("dialpad") {
                        popUpTo("dial") { inclusive = false }
                    }
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color.Black)
        ) {
            Image(
                painter = painterResource(R.drawable.end_button),
                contentDescription = "End Call"
            )
        }
    }

    // after 2 seconds user will go to the incoming call screen
    LaunchedEffect(key1 = true) {
        delay(2000)
        if (!callEnded) { // Only navigate if user did NOT end the call manually
            val encodedNumber = java.net.URLEncoder.encode(number, java.nio.charset.StandardCharsets.UTF_8.toString())
            navController.navigate("incoming/$encodedNumber")
        }
    }
}